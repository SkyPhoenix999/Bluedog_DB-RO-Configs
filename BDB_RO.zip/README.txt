//	================================================================================
//	README
//	================================================================================


WIP Realism Overhaul support for the Bluedog Design Bureau Mod

Requires the test .dll files for B9PartSwitch and RealFuels you can find on the RealismOverhaul Discord

If you want to use the engines, you need to delete the PatchManager folder from ROEngines, otherwise the engines in BDB will not show up


NOTES:

- This download only includes full support for the rockets in BDB, and partial support for the probes.
- The Capsules are partially configured but do not use them unless you are debugging them

- This is a TEST DOWNLOAD, do not use it unless you are trying to help out
- with the Development of these configs. This is not a finished product.
